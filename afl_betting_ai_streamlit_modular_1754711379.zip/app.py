# minimal placeholder
import streamlit as st
st.write('Hello from AFL AI bundle')
